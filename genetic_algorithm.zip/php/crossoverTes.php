<?php

    function crossover($parentA, $parentB){
        global $CROSSOVER_RATE;

        $ia_before_cp = substr($parentA, 0, $CROSSOVER_RATE);
        //$ia_after_cp  = substr($ia[0], $crosspoint);
        //$ib_before_cp = substr($ib[0], 0, $crosspoint);
        $ib_after_cp  = substr($parentB, $CROSSOVER_RATE);
        $child = $ia_before_cp.$ib_after_cp;

        return $child;
    }

    $CROSSOVER_RATE = 4;
    $orangTuaA = 10101010;
    $orangTuaB = 01010101;
    $anak = crossover($orangTuaA, $orangTuaB);
    echo $orangTuaA;
    echo "<br>";
    echo $orangTuaB;
    echo "<br>";
    echo $anak;
